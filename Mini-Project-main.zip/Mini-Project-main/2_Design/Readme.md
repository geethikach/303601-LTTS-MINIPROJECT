# Design
## ![Tip](https://img.shields.io/badge/Tip-Please%20Turn%20On%20Light%20Mode%20for%20better%20viewing-green)
## High Level Design 
### Architecture Design :
![Architecture](https://github.com/260230/Mini-Project/blob/main/2_Design/High%20level%20Architecture%20design.png)
### Insertion Sort Diagram :
![InsertionDiagram](https://github.com/260230/Mini-Project/blob/main/2_Design/insertion%20sort.png)

### Bubble Sort Diagram :
![BubbleSortDiagram](https://github.com/260230/Mini-Project/blob/main/2_Design/Bubble%20sort.png)

### Quick Sort Diagram :
![QuickSortDiagram](https://github.com/260230/Mini-Project/blob/main/2_Design/quick%20sort.png)

### Merge Sort Diagram :
![MergeSortDiagram](https://github.com/260230/Mini-Project/blob/main/2_Design/merge%20sort.png)
